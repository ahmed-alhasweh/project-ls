import { Component, xml, useState } from "@odoo/owl";
import { NewProgrammes } from "./NewProgrammes";
import { NewBusinessManagement } from "./NewBusinessManagement";
import { NewHealthAndSocialCare } from "./NewHealthAndSocialCare";
import "../../src/assets/style.css"


export class Tabs extends Component {
    static components = { NewProgrammes, NewBusinessManagement, NewHealthAndSocialCare };
  static template = xml`
  <div class="tabs">
    <div class="tabs-header">
      <span t-foreach="state.tabs" t-as="tab" t-on-click="() => this.selectTab(tab.id)" t-key="tab.id" t-att-class="{'active': state.activeTab === tab.id}">
      
      <t t-esc="tab.label" />
      </span>
    </div>
    <div class="tabs-content">
      <t t-foreach="state.tabs" t-as="tab" t-key="tab.id">
        <div t-if="state.activeTab === tab.id" class="course-cards">
          <t t-component="tab.contentTemplate" />
        </div>
      </t>
    </div>
  </div>`;

  setup () {
    this.state = useState({ 
        activeTab: 1,
        tabs: [
            { id: 1, label: "New Programmes", contentTemplate: NewProgrammes },
            { id: 2, label: "New in Business Management", contentTemplate: NewBusinessManagement },
            { id: 3, label: "New in Health and Social Care", contentTemplate: NewHealthAndSocialCare },
        ]
    });
  }
  
  
  selectTab(id) {
    this.state.activeTab = id;
 }
}
