import { Component, xml } from "@odoo/owl";
import courseImage from '../assets/course.jpg';
import courseImage2 from '../assets/course2.jpg';

export class NewProgrammes extends Component {
  static template = xml`
  <div class="tab-content">
    <!-- Repeat for each programme card -->
    <div class="card">
      <img t-att-src="props.courseImage" alt="Programme Image" />
      <h3>Programme Title 1</h3>
      <p>Programme description 1.</p>
    </div>
    <div class="card">
      <img t-att-src="props.courseImage2" alt="Programme Image" />
      <h3>Programme Title 2</h3>
      <p>Programme description 2.</p>
    </div>
  </div>`;
  setup() {
    this.props = {
      courseImage,
      courseImage2,
    };
  }
}
