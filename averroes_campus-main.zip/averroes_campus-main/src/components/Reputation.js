import { Component, xml } from "@odoo/owl";
import "../../src/assets/style.css";

export class Reputation extends Component {
  static template = xml`
    <section class="reputation" id="reputation" t-on-mouseover="animateNumbers">
      <h2>Our Reputation</h2>
      <p class="reputation-description">
        Averroes Campus Education is proud to have come a long way since inception, by successfully bringing accredited British degree and diploma programmes to students around the world, from acclaimed university partners. Our most prominent MBA programmes have over 2000 successful graduates up to date.
      </p>
      <div class="stats">
        <div class="stat">
          <h3>Undergraduate Admissions</h3>
          <p class="number" data-target="2000">0<span>+</span></p>
        </div>
        <div class="stat">
          <h3>Masters and MBA Admissions</h3>
          <p class="number" data-target="7500">0<span>+</span></p>
        </div>
        <div class="stat">
          <h3>Doctoral and DBA Admissions</h3>
          <p class="number" data-target="500">0<span>+</span></p>
        </div>
        <div class="stat">
          <h3>Courses</h3>
          <p class="number" data-target="300">0<span>+</span></p>
        </div>
        <div class="stat">
          <h3>Total Admissions</h3>
          <p class="number" data-target="10000">0<span>+</span></p>
        </div>
        <div class="stat">
          <h3>Universities</h3>
          <p class="number" data-target="20">0<span>+</span></p>
        </div>
      </div>
    </section>
  `;

  animateNumbers() {
    const counters = document.querySelectorAll(".number");
    const duration = 1000;

    counters.forEach(counter => {
      const target = +counter.getAttribute('data-target');
      const increment = target / (duration / 16);
      let count = 0;

      const updateCount = () => {
        count += increment;
        if (counter.innerText == target + "+"){
          return;
        }
        if (count < target) {
          counter.innerText = Math.ceil(count) + "+";
          setTimeout(updateCount, 16);
        } else {
          counter.innerText = target + "+";
        }
        
      };
    updateCount();
    });
  }
}
