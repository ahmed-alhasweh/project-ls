import { Component, xml } from "@odoo/owl";
import "../../src/assets/style.css"

export class Header extends Component {
    static template =  xml`
    <header>
      <img src="https://chestnuteducationgroup.net/wp-content/uploads/2020/09/CE-Logo.svg" alt="Logo" />
      <nav>
        <a class="nav-element" href="#">Averroes Campus Foundation</a>
        <a class="nav-element2" href="#">Blog</a>
      </nav>
      <div class="">
          <div class="main-header search-container">
            <input class="search-side-input" type="text" placeholder="Course Search" />
            <button class="search-side-option">
              <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0,0,256,256"
              style="fill:#000000;">
              <g fill="#636262" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><g transform="scale(10.66667,10.66667)"><path d="M9,2c-3.85415,0 -7,3.14585 -7,7c0,3.85415 3.14585,7 7,7c1.748,0 3.34501,-0.65198 4.57422,-1.71875l0.42578,0.42578v1.29297l6,6l2,-2l-6,-6h-1.29297l-0.42578,-0.42578c1.06677,-1.22921 1.71875,-2.82622 1.71875,-4.57422c0,-3.85415 -3.14585,-7 -7,-7zM9,4c2.77327,0 5,2.22673 5,5c0,2.77327 -2.22673,5 -5,5c-2.77327,0 -5,-2.22673 -5,-5c0,-2.77327 2.22673,-5 5,-5z"></path></g></g>
              </svg>
            </button>
            
          </div>
          <div class="main-header">
            <nav>
              <a class="side-nav-el" href="#">Study With Us</a>
              <a class="side-nav-el" href="#">Universities</a>
              <a class="side-nav-el" href="#">About Us</a>
              <a class="side-nav-el" href="#">Contact Us</a>
            </nav>
          </div>
      </div>
    </header>`;
}