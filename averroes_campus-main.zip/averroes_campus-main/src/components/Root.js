import { Component, xml } from "@odoo/owl";
import { Header } from "./Header";
import { Hero } from "./Hero";
import { NewCourses } from "./NewCourses";
import { FeaturedCourses } from "./FeaturedCourses";
import { Reputation } from "./Reputation";
import { Testimonials } from "./Testimonials";
import { TopCourses } from "./TopCourses";
import { Partners } from "./Partners";
import { PostgraduateCourses } from "./PostgraduateCourses";
import { Footer } from "./Footer";
import "../../src/assets/style.css"

export class Root extends Component {
  static components = { 
    Header,
    Hero,
    NewCourses,
    FeaturedCourses,
    Reputation,
    Testimonials,
    TopCourses,
    Partners,
    PostgraduateCourses,
    Footer
  };

  static template = xml`
    <div>
      <Header />
      <Hero />
      <NewCourses />
      <FeaturedCourses />
      <Reputation />
      <Testimonials />
      <TopCourses />
      <Partners />
      <PostgraduateCourses />
      <Footer />
    </div>
  `;
}