import { Component, xml } from "@odoo/owl";
import businessImage from '../assets/business.jpg';
import businessImage2 from '../assets/business2.jpg';

export class NewBusinessManagement extends Component {
  static template = xml`
  <div class="tab-content">
    <!-- Repeat for each programme card -->
    <div class="card">
      <img t-att-src="props.businessImage" alt="Business Image" />
      <h3>Business Title 1</h3>
      <p>Business description 1.</p>
    </div>
    <div class="card">
      <img t-att-src="props.businessImage2" alt="Business Image" />
      <h3>Business Title 2</h3>
      <p>Business description 2.</p>
    </div>
  </div>`;
  setup() {
    this.props = {
      businessImage,
      businessImage2,
    };
  }
}
