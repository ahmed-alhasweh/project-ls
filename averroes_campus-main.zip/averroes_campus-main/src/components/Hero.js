import { Component, xml } from "@odoo/owl";
import "../../src/assets/style.css"

export class Hero extends Component {
  static template = xml`
    <section class="hero">
      <div>
        <h1>Bringing Online Education to Your Doorstep</h1>
        <div class="hero-content">Averroes Campus Education is a pioneering 
        private higher education organisation, accredited and working in 
        partnership with leading universities and professional bodies 
        internationally.</div>
      </div>
      <div class="search-container search-container2">
        <input class="search-input" type="text" placeholder="Course Search" />
        <button class="search-logo">
        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="32" height="32" viewBox="0,0,256,256"
          style="fill:#000000;">
        <g fill="#ffffff" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><g transform="scale(8,8)"><path d="M19,3c-5.51172,0 -10,4.48828 -10,10c0,2.39453 0.83984,4.58984 2.25,6.3125l-7.96875,7.96875l1.4375,1.4375l7.96875,-7.96875c1.72266,1.41016 3.91797,2.25 6.3125,2.25c5.51172,0 10,-4.48828 10,-10c0,-5.51172 -4.48828,-10 -10,-10zM19,5c4.42969,0 8,3.57031 8,8c0,4.42969 -3.57031,8 -8,8c-4.42969,0 -8,-3.57031 -8,-8c0,-4.42969 3.57031,-8 8,-8z"></path></g></g>
        </svg>
        </button>
      </div>
    </section>
  `;
}
