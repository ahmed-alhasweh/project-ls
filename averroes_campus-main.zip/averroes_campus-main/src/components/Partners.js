import { Component, xml } from "@odoo/owl";
import "../../src/assets/style.css";

export class Partners extends Component {
  static template = xml`
    <section class="partners">
      <h2>Our Partners</h2>
      <p class="partners-description">
        Averroes Campus Education works in partnership with many leading universities and professional bodies internationally, to bring a choice of Bachelor’s, Master’s, Doctorate, Diploma and Certification programmes to you.
      </p>
      <div class="carousel-container">
        <div class="carousel">
          <div class="partner-logos">
            <img src="https://www.sisli.edu.tr/wp-content/uploads/2019/09/logo_article_white_smyo-e1576859757687.png" alt="T.C. İstanbul Şişli Meslek Yüksekokulu" />
            <img src="https://www.sisli.edu.tr/wp-content/uploads/2019/09/logo_article_white_smyo-e1576859757687.png" alt="T.C. İstanbul Şişli Meslek Yüksekokulu" />
            <img src="https://www.sisli.edu.tr/wp-content/uploads/2019/09/logo_article_white_smyo-e1576859757687.png" alt="T.C. İstanbul Şişli Meslek Yüksekokulu" />
            <img src="https://www.sisli.edu.tr/wp-content/uploads/2019/09/logo_article_white_smyo-e1576859757687.png" alt="T.C. İstanbul Şişli Meslek Yüksekokulu" />
            <!-- Repeat logos to ensure the continuous flow -->
          </div>
        </div>
      </div>
      <button class="view-all-button">More About Our Partners</button>
    </section>
  `;
}
