import { Component, xml } from "@odoo/owl";
import healthSocialCareImage from '../assets/health.jpg';
import healthSocialCareImage2 from '../assets/health2.jpg';

export class NewHealthAndSocialCare extends Component {
  static template = xml`
  <div class="tab-content">
    <!-- Repeat for each programme card -->
    <div class="card">
      <img t-att-src="props.healthSocialCareImage" alt="Health Image" />
      <h3>Health Title 1</h3>
      <p>Health description 1.</p>
    </div>
    <div class="card">
      <img t-att-src="props.healthSocialCareImage2" alt="Health Image" />
      <h3>Health Title 2</h3>
      <p>Health description 2.</p>
    </div>
  </div>`;
  setup() {
    this.props = {
      healthSocialCareImage,
      healthSocialCareImage2,
    };
  }
}
