import { Component, xml } from "@odoo/owl";
import "../../src/assets/style.css"


export class Footer extends Component {
  static template = xml`
  <footer>
    <div class="footer-content">
      <div class="footer-section">
        <h4>Links</h4>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">Courses</a></li>
          <li><a href="#">About Us</a></li>
        </ul>
      </div>
      <div class="footer-section">
        <h4>Contact Us</h4>
        <ul>
          <li>Email</li>
          <li>Phone</li>
        </ul>
      </div>
      <div class="footer-section">
        <h4>Social Media</h4>
        <ul class="">
          <li><a href="#">Facebook</a></li>
          <li><a href="#">Twitter</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <p>Bringing Online Education to Your Doorstep | Averroes Campus Education</p>
      <p>Lorem ipsum dolor sit amet.</p>
    </div>
  </footer>`;
}