import { Component, xml } from "@odoo/owl";
import bachelorImage from '../assets/bachelor.jpg';
import uniImage from '../assets/university.jpg';
import dlImage from '../assets/distanceL.jpg';
import llmImage from '../assets/llm.jpg';

export class TopCourses extends Component {
  static template = xml`
    <section class="featured-courses">
      <h2>Featured Courses</h2>
      <p class="featured-courses-description">
        We are proud to feature a variety of courses on our portfolio, ranging from technology and business to health and social care. Our featured courses are carefully selected to provide students with the most relevant and up-to-date knowledge and skills and designed to help students achieve their career goals.
      </p>
      <div class="course-cards">
        <div class="card">
          <img t-att-src="props.uniImage" alt="Qualifi Level 5 Extended Diploma in Law" />
          <h3>Qualifi Level 5 Extended Diploma in Law</h3>
          <p>Distance Learning<br/>6 months</p>
          <p class="university">QUALIFI</p>
        </div>
        <div class="card">
          <img t-att-src="props.bachelorImage" alt="Bachelor of Laws LLB (Hons) (Top-Up)" />
          <h3>Bachelor of Laws LLB (Hons) (Top-Up)</h3>
          <p>Distance Learning<br/>12 months</p>
          <p class="university">University of Central Lancashire (UCLan)</p>
        </div>
        <div class="card">
          <img t-att-src="props.dlImage" alt="MBA (Top-Up)" />
          <h3>MBA (Top-Up)</h3>
          <p>Distance Learning<br/>4 months</p>
          <p class="university">University of Central Lancashire (UCLan)</p>
        </div>
        <div class="card">
          <img t-att-src="props.llmImage" alt="Master of Laws (LLM) (Top-Up)" />
          <h3>Master of Laws (LLM) (Top-Up)</h3>
          <p>Distance Learning<br/>9 months</p>
          <p class="university">University of Central Lancashire (UCLan)</p>
        </div>
      </div>
      <button class="view-all-button">View All Courses</button>
    </section>
  `;
  setup() {
    this.props = {
      bachelorImage,
      uniImage,
      dlImage,
      llmImage,
    };
  }
}