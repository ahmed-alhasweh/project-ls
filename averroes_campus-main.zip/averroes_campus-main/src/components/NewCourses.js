import "../../src/assets/style.css"
import { Component, xml } from "@odoo/owl";
import { Tabs } from "./Tabs";
import { NewProgrammes } from "./NewProgrammes";
import { NewBusinessManagement } from "./NewBusinessManagement";
import { NewHealthAndSocialCare } from "./NewHealthAndSocialCare";

export class NewCourses extends Component {
  static components = { Tabs, NewProgrammes, NewBusinessManagement, NewHealthAndSocialCare };
  static template = xml`
  <section class="new-courses">
    <h2>What's New</h2>
    <Tabs />
  </section>`;
}
