import { Component, xml, useState } from "@odoo/owl";
import "../../src/assets/style.css"
import student1 from "../assets/student1.jpg";
import student2 from "../assets/student2.jpg";


export class Testimonials extends Component {
  static template = xml`
    <section class="testimonials">
      <h2>What Students Say</h2>
      <div class="slider">
        <div t-foreach="state.testimonials" t-as="testimonial" t-key="testimonial.id" class="testimonial" t-att-class="{'active': state.currentTestimonial === testimonial.id}">
          <p t-esc="testimonial.comment"/>
          <div class="author">
            <img t-att-src="testimonial.image" />
            <div>
              <div class="name" t-esc="testimonial.name"></div>
              <div class="details" t-esc="testimonial.details"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="dots">
        <span t-foreach="state.testimonials" t-as="testimonial" t-key="testimonial.id" class="dot" t-att-class="{'active': state.currentTestimonial === testimonial.id}" t-on-click="() => this.selectTestimonial(testimonial.id)"></span>
      </div>
    </section>
  `;
  

  state = useState({
    testimonials: [
      {
        id: 1,
        comment: "I would definitely recommend Averroes Campus Education.",
        image: student1,
        name: "Zainab Tabasso",
        details: "BA (Hons) Business Management (2021)"
      },
      {
        id: 2,
        comment: "I recommend Averroes Campus Education. They are professional and extremely reliable. All my queries were resolved within a short timeframe. Anton Dominique has an exceptional work ethic. He was always professional and willing to offer support.",
        image: student2,
        name: "Ahmed Jamal",
        details: "BA (Hons) Business Management (2024)"
      },
    ],
    currentTestimonial: 1
  });

  selectTestimonial(id) {
    this.state.currentTestimonial = id;
  }
  setup(){
    this.state.props = {
      student1,
      student2
    }
  }
}

