import { mount } from "@odoo/owl";
import { Root } from "./components/Root";
import './assets/style.css';

function setup() {
  const target = document.getElementById('app');
  if (!target) {
    target = document.body
  }
  mount(Root,  target);
}

setup();
