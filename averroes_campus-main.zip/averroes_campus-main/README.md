# Averroes Campus

This project built with the Owl framework and Webpack. The components dynamically display the landing page.

## Table of Contents
- [Installation](#installation)
- [Usage](#usage)
- [Development](#development)

## Installation

### Prerequisites
- Node.js (>= 20.10)
- npm (>= 10.5)
- webpack (>= 5.90)

### Steps
1. Clone the repository:
   ```bash
   git clone https://github.com/nssuu/averroes_campus.git
   cd averroes_campus
2. Install dependencies.
   ```bash
    npm install
### Usage
1. Build the project using Webpack:
    ```bash
      npm run build

### Development
#### Running in Development Mode
- To start a development server with hot reloading:
  ```bash 
    npm start
- This will start the server at localhost:{port}
--- 
### File Structure
```txt
|-- src
|   |-- assets
|   |   |-- style.css
|   |   |-- student1.jpg
|   |   |-- student2.jpg
|   |   |-- style.css
|   |-- components
|   |   |-- Header.js
|   |   |-- Testimonials.js
|   |   |-- ComponentExample.js
|-- dist
|-- index.html
|-- index.js
|-- package.json
|-- webpack.config.js 
```


### Demo
https://github.com/nssuu/averroes_campus/assets/60490369/94f0a8e4-aebf-4bd3-9693-8893e1506627


