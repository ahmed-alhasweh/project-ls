module.exports = {
    verbose: false,
    testRegex: "(/tests/.*(test|spec))\\.js?$",
    moduleFileExtensions: ["js"],
    transform: {
      "^.+\\.[t|j]sx?$": "babel-jest"
    }
  };
  